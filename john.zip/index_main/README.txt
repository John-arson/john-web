!!!THIS IS STILL A WORK IN PROGRESS!!!
if you don't know html, just open the index.htm file in your browser (make sure to fully extract the zip first)
if you do know html, please fix it, my html is genuinely horrible